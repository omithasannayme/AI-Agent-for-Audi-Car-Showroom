(function () {
  const HISTORY_KEY = "audi_chat_history_v1";
  const THEME_KEY = "audi_chat_theme_v1";

  const messagesEl = document.getElementById("messages");
  const formEl = document.getElementById("chatForm");
  const inputEl = document.getElementById("userInput");
  const sendBtn = document.getElementById("sendBtn");
  const clearBtn = document.getElementById("clearBtn");
  const themeSelect = document.getElementById("themeSelect");

  let history = [];

  function saveHistory() {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    } catch (e) { /* storage full or blocked */ }
  }

  function loadHistory() {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      return [];
    }
  }

  function scrollToBottom() {
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function renderMessage(role, text) {
    const div = document.createElement("div");
    div.className = "msg " + role;
    div.textContent = text;
    messagesEl.appendChild(div);
    scrollToBottom();
    return div;
  }

  function addMessage(role, text) {
    history.push({ role: role, text: text });
    saveHistory();
    return renderMessage(role, text);
  }

  function showWelcome() {
    const app = document.getElementById("chatApp");
    addMessage("bot", app.dataset.welcomeEn || "");
  }

  function showTyping() {
    const div = document.createElement("div");
    div.className = "msg bot";
    div.innerHTML = '<span class="typing"><span></span><span></span><span></span></span>';
    messagesEl.appendChild(div);
    scrollToBottom();
    return div;
  }

  async function sendMessage(text) {
    addMessage("user", text);
    inputEl.value = "";
    sendBtn.disabled = true;
    const typing = showTyping();

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text })
      });
      const data = await res.json();
      typing.remove();
      addMessage("bot", data.reply || "…");
    } catch (err) {
      typing.remove();
      addMessage("bot", "Connection error. Please make sure the server is running.\nসংযোগ সমস্যা। সার্ভার চালু আছে কি না দেখুন।");
    } finally {
      sendBtn.disabled = false;
      inputEl.focus();
    }
  }

  formEl.addEventListener("submit", function (e) {
    e.preventDefault();
    const text = inputEl.value.trim();
    if (text) sendMessage(text);
  });

  clearBtn.addEventListener("click", function () {
    history = [];
    saveHistory();
    messagesEl.innerHTML = "";
    showWelcome();
  });

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    themeSelect.value = theme;
    try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* ignore */ }
  }

  themeSelect.addEventListener("change", function () {
    applyTheme(themeSelect.value);
  });

  // Init
  let savedTheme = "light";
  try { savedTheme = localStorage.getItem(THEME_KEY) || "light"; } catch (e) { /* ignore */ }
  applyTheme(savedTheme);

  history = loadHistory();
  if (history.length === 0) {
    showWelcome();
  } else {
    history.forEach(function (m) { renderMessage(m.role, m.text); });
  }
  inputEl.focus();
})();