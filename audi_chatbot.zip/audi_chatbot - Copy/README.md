# Audi Showroom Bangladesh – Bilingual Chatbot

A local web chatbot (English and Bengali) that answers only questions about
buyer documents, payment documents, vehicle registration papers, and Audi
models and prices. It uses Python 3.13, Flask, and a small local Ollama model.
There is no database; all knowledge is in `data/knowledge.json`.

## Requirements
- Python 3.13
- Ollama (https://ollama.com/download)
- About 1 GB free disk space for the model

## Setup
1. Install Ollama, then pull a small model:
   ollama pull qwen3:0.6b
2. Open the project folder in PyCharm (or a terminal).
3. Create and activate a virtual environment:
   Windows:  python -m venv .venv  then  .venv\Scripts\activate
   macOS/Linux:  python3 -m venv .venv  then  source .venv/bin/activate
4. Install dependencies:
   pip install -r requirements.txt
5. Put a background car photo at static/img/bg.jpg
   (use an image you have the right to use).
6. Edit data/knowledge.json: set support_phone and showroom_name,
   and add real models and prices from the official Audi website.
7. Start Ollama (if it is not already running): ollama serve
8. Run the app: python app.py
9. Open http://127.0.0.1:5000

## Choosing another model
Windows (PowerShell):  $env:OLLAMA_MODEL="qwen3:0.6b"
macOS/Linux:           export OLLAMA_MODEL="qwen3:0.6b"
Then run python app.py again.

## How scope is enforced
- Questions with no keyword match in the dataset get a fixed refusal
  with the support phone number; the model is not called.
- Matching questions send only the relevant dataset text to the model,
  with a strict system prompt.
- If the model fails, the stored dataset answer is returned.

## Chat memory
Chat history and theme are saved in the browser (localStorage).
The server stores nothing. The Clear button resets the history.

## Updating knowledge
Edit data/knowledge.json and restart python app.py.
Keep at least 50 synonyms per topic; the server prints a warning at
startup if any topic has fewer.